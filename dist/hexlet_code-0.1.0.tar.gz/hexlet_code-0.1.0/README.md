### Hexlet tests and linter status:
[![Actions Status](https://github.com/Petr-Korolev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Petr-Korolev/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/d79424c3a22d1fb8bbec/maintainability)](https://codeclimate.com/github/Petr-Korolev/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/50EbQSfvxSdsbcDCJcIcZp0X2.svg)](https://asciinema.org/a/50EbQSfvxSdsbcDCJcIcZp0X2)
